/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula1;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Aluno
 */
public class Aula1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       JFrame janela = new JFrame("Projeto Disciplina - Narinha Galvão!");
       JPanel painel = new JPanel();
       janela.setSize(300,200);
       janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       janela.setVisible (true);
       janela.add(painel);
       JLabel rotulo = new JLabel ();
       String number =JOptionPane.showInputDialog("Digite um numero");
       //JOptionPane.showMessageDialog(null, "o Número digitado foi " + number, "IFRO", JOptionPane.ERROR_MESSAGE);
       JOptionPane.showMessageDialog(null, "o Número digitado foi " + number, "IFRO", JOptionPane.PLAIN_MESSAGE);
       //Icon icone = new ImageIcon(getClass().getResource());
       //rotulo.setIcon(icone);
      // rotulo.setIcon(new ImageIcon(getClass().getResource("/imagem")));
       painel.add(rotulo);
    }
    
}
